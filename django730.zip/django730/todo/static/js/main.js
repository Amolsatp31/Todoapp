function greet(){

    alter("Javascript file is linked properly");
}